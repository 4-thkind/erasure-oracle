# Evaluation Report

Ghost Data Still Exists, HackerRank Orchestrate October 2026.

Everything below was measured on the final code in `code/`, with `dataset/` left untouched. The
evaluation scripts are part of the submission:

```bash
python evaluation/main.py            # 32 supplied sample cases
python evaluation/custom_cases.py    # 5 participant authored cases
python evaluation/validate_output.py # contract validation of output.csv
```

---

## 1. Summary

| Measure | Result |
|---|---|
| Sample cases | 32 |
| Deletion status accuracy | **32 / 32 (1.000)** |
| Expected steps | 193 |
| Produced steps | 183 |
| Aligned steps | 182 |
| Step precision | **0.995** |
| Step recall | **0.943** |
| Step F1 | **0.968** |
| Step accuracy (aligned over max) | **0.943** |
| Sequence accuracy (whole step list identical) | **22 / 32 (0.688)** |
| Field accuracy on aligned steps | **182 / 182 (1.000)** for phase, system, resource, operation, state, evidence |
| Contract validation of the 518 row submission | **0 errors** |
| Participant authored cases | **5 / 5 exact match** |

The distinction between the aligned field score and the sequence score matters. When a step is
present, every one of its six decision fields is correct: nothing is misfiled, mislabelled or
misquoted. The remaining loss is entirely about steps that cannot be produced at all, plus one
case where the account record was named incorrectly. Section 4 lists them one by one.

---

## 2. Sample set results in full

```text
sample cases                 : 32
status accuracy              : 32/32  (1.000)

expected steps               : 193
produced steps               : 183
aligned steps                : 182
step precision               : 0.995
step recall                  : 0.943
step F1                      : 0.968
step accuracy (aligned/max)  : 0.943
sequence accuracy            : 22/32  (0.688)

field step_no      : 172/194  (0.887)
field phase        : 182/194  (0.938)
field system_id    : 182/194  (0.938)
field resource_id  : 182/194  (0.938)
field operation    : 182/194  (0.938)
field state        : 182/194  (0.938)
field evidence_id  : 182/194  (0.938)

on aligned steps only (identity already matched):
  phase        : 182/182  (1.000)
  system_id    : 182/182  (1.000)
  resource_id  : 182/182  (1.000)
  operation    : 182/182  (1.000)
  state        : 182/182  (1.000)
  evidence_id  : 182/182  (1.000)
```

`step_no` scores lower than the other fields only because numbering shifts when an earlier step is
missing from the answer. It is not a numbering error.

### How the evaluator aligns steps

Steps are matched on their identity tuple `(phase, system_id, resource_id, operation, state)` as a
multiset, and only then compared field by field. Aligning by position would charge one ordering
mistake twice and would report field errors that do not exist. Leftover produced steps count as
false positives, leftover expected steps count as false negatives, and every unmatched step counts
as six wrong fields, so the per field numbers cannot be inflated by skipping hard rows.

### Real set behaviour

The same pipeline run over `dataset/deletion_requests.csv` produces 518 rows and 2807 steps in
about 5 seconds:

| Measure | Result |
|---|---|
| Rows written | 518 |
| COMPLETE | 159 |
| INCOMPLETE | 349 |
| NOT_APPLICABLE | 10 |
| Steps | 2807 |
| Rows citing an artifact outside the case window | 1 (documented in section 4.6) |
| Rows with no step at all | 0 |

`validate_output.py` re reads the manifest, the activity stream and the policy file, and checks the
submission independently of the pipeline:

- header and row count, one row per requested case, no duplicates, no unknown cases
- status vocabulary, step vocabulary, operation to state to phase consistency
- consecutive `step_no`, phase ordering, permitted operations only
- citation provenance: every `evidence_id` is a real `file_id`, `activity_id` or `audit_id`
- citation timing: every cited artifact was captured at or before the case `audit_at`
- COMPLETE answers carry verification steps only, each with a citation
- INCOMPLETE findings all cite evidence, remediation and future checks cite nothing
- every finding has a matching remediation of the right kind, and every remediated record is
  verified afterwards
- policy legality: a retained or blocked category is never deleted, redacted or anonymized

Final run: `errors: 0`.

---

## 3. Participant authored evaluation cases

The sample set is also the tuning signal, so it is a biased measure: every rule in the agent was
eventually shaped by it. These five cases were written from scratch against `problem_statement.md`
only, with a synthetic mini dataset built inside a temporary directory, so the whole pipeline path
runs unmodified (identity resolution, evidence parsing, policy, planner, account anchoring,
ordering, serialisation).

Run output:

```text
  custom_01  PASS  status=COMPLETE       steps=5  expected=5
  custom_02  PASS  status=INCOMPLETE     steps=17 expected=17
  custom_03  PASS  status=NOT_APPLICABLE steps=0  expected=0
  custom_04  PASS  status=COMPLETE       steps=3  expected=3
  custom_05  PASS  status=INCOMPLETE     steps=3  expected=3
```

### custom_01, historical email plus tombstone retention, COMPLETE

The request arrives from an address the person stopped using in 2025; the current identity snapshot
holds a different address. The fixture shows the account profile gone, a tombstone that keeps only
the stable `user_id`, a security audit record that policy retains, a connector that is off, and a
backup whose restore is blocked. Expected answer:

| # | Phase | System | Resource | Operation | Evidence |
|---|---|---|---|---|---|
| 1 | VERIFICATION | account_service | account_9101 | VERIFY_RECORD_ABSENT | evidence_c01 |
| 2 | VERIFICATION | security_service | audit_record_9101 | VERIFY_RECORD_PRESENT | evidence_c01 |
| 3 | VERIFICATION | identity_service | tombstone_9101 | VERIFY_RECORD_REDACTED | evidence_c01 |
| 4 | VERIFICATION | integration_service | data_flow_9101 | VERIFY_DATA_FLOW_DISABLED | evidence_c01 |
| 5 | VERIFICATION | backup_service | backup_9101 | VERIFY_RESTORE_BLOCKED | evidence_c01 |

This case fails immediately if the resolver only knows current addresses, if the tombstone is
treated as a violation, or if a retained record is "cleaned up".

### custom_02, every finding and remediation kind at once, INCOMPLETE

A search document still indexed, an analytics profile still attributable, a support conversation
still carrying the customer address, a live connector, and a restorable archive. 17 steps: 5
findings, 5 remediation steps, 7 post remediation checks.

The ordering requirement is the point. Remediation comes out as `DISABLE_DATA_FLOW`,
`BLOCK_RESTORE`, `DELETE_RECORD`, `REDACT_RECORD`, `ANONYMIZE_RECORD`, which is the operation order
from the problem statement and also the safe order: copying and restoring are stopped before any
record is touched, so a sync cannot recreate a record that was just deleted. Findings are ordered by
the same table, then system, then resource.

### custom_03, access request, NOT_APPLICABLE

"Please send me a copy of everything you hold about me so I can review it." All other fields look
like a deletion case, the person even has an identity and a reported status. The answer must be
`NOT_APPLICABLE` with `steps_json` empty. A false positive here would invent findings for a person
who never asked for erasure.

### custom_04, evidence captured after `audit_at`, COMPLETE

At `audit_at` the analytics record is anonymized, the account profile is gone, and the security
audit record is retained. A bundle captured four days later shows the analytics record with an
email again and a new support ticket with the address. Both are after the cutoff, so both must be
ignored: the answer stays COMPLETE with three verification steps, all citing the earlier artifact
`evidence_c04a`, and the late artifact `evidence_c04b` must not appear anywhere in the row.

This is the case that guards the two clock rule. A row inside a snapshot can carry a timestamp
older than the artifact itself, and the tempting mistake is to let that row decide the answer.

### custom_05, replication drift, INCOMPLETE

Two SQL captures of the same account: the primary is deleted, the regional replica still holds the
full profile with name and email one day before `audit_at`. The newest copy of the record wins, so
the answer is `REPORT_REMAINING_RECORD` on the replica, `DELETE_RECORD`, then
`VERIFY_RECORD_ABSENT`. Trusting the primary, or merging replicas by "the first row seen", turns a
real ghost record into a false COMPLETE.

---

## 4. Failures found and improvements made

Each item below was found by measuring, not by guessing. The order is the order they were found.

### 4.1 Trusting workflow claims

First version read `reported_status` and `reported_result` as the answer. The sample set showed
immediately that a workflow can report COMPLETE while records remain, and that a worker row can
report FAILED for a record that is in fact gone. Fix: workflow status is never an input to the
verdict. It is only used, later, as a hint for naming an account record that the snapshots lost.

### 4.2 Latest observation wins, with a cutoff

Records are reconciled per `(system, resource)`: the newest observation at or before `audit_at`
decides the state. This is what makes replication drift visible, because the replica capture is
newer than the primary capture.

### 4.3 The two clock rule

An artifact whose manifest `captured_at` is after `audit_at` may never decide a case, even when its
internal rows or per store snapshot times are earlier. The first implementation only compared the
row time and produced confident findings from bundles collected weeks after the audit. Fix: an
observation carries both its own timestamp and its artifact timestamp; a late artifact may still
name a resource (ownership index) and may still prove a compliant state, because a check step needs
no citation, but a violation must come from a cited artifact. Evidence accuracy on aligned steps
went from 0.86 to 1.00 with this change alone.

### 4.4 Missing account records

Some cases have no account row in any snapshot because the profile was already deleted. Reporting
nothing is wrong: an absent account is exactly what a completed deletion should prove. Fix: the
account identifier is recovered from the ownership index, and when it appears nowhere, from the
deletion worker stream (`source_system=deletion_worker`, `target_system=account_service`,
`event_type=DELETE_RECORD`) by group bijection against the cases reported in the same time window.
A recovered identifier is only ever used for an absent account check, never for a finding, so a
wrong guess cannot flip a status. 17 of 518 cases need this path.

### 4.5 Intent classification

Two failures: a follow up that asks the desk to confirm that the profile is gone was read as a non
deletion contact, and a message with an explicit withdrawal was read as authorising deletion. Fix:
withdrawal patterns are evaluated first and win over deletion words; a set of confirmation patterns
("profile is gone", "cannot identify me", "no longer identifiable") authorises the audit. Status
accuracy on the sample set has been 32/32 since.

### 4.6 A case with no artifact in its window

`case_61` is audited on 2026-02-14 and no artifact captured at or before that date mentions the
subject at all; the only mention anywhere is a support attachment from September. An empty COMPLETE
answer is not a usable answer, so the pipeline falls back to the earliest artifact after `audit_at`
that names the subject and says so in the case note. This is the single row in the submission whose
citation lies outside its window, and `validate_output.py` reports it separately as a documented
fallback rather than as an error.

### 4.7 Multi word resource prefixes

`infer_category` split a resource id on the first underscore, so `audit_record_003` was read as
prefix `audit` and fell through to "unknown category". Unknown categories default to a delete
policy, which produced a spurious VERIFY_RECORD_ABSENT next to the real retained audit record for
`case_45`. Fix: longest known prefix match. Retained, anonymized and tombstone records are now
classified correctly no matter which parser found them.

### 4.8 Ownership rows are not state rows

A link row in the activity stream ties a resource to a person, and it was being read as if it also
asserted a state. For connectors and backups that is wrong: "linked to this user" says nothing about
whether a sync is running or a restore is possible. Left as is, the agent answered COMPLETE with a
made up "flow disabled" check for two cases. Fix: such rows carry an explicit unknown state, they
are skipped when deciding a state, and they still feed the ownership index.

### 4.9 Screenshots

Eleven PNGs carry no text layer and were producing zero observations. Their visible facts were read
once by the agent and stored in `code/vision_cache.json` with the file id, the focal record, the
visible identifiers and the state the screen establishes. Ten of the eleven map exactly to resources
that had no other evidence. Two of them change a verdict: a connector console showing 1,284 events
per hour and a backup console showing restore success 99.6 percent. Without them those two cases
were "COMPLETE" with an invented disabled check. With them they are `REPORT_ACTIVE_DATA_FLOW` and
`REPORT_RESTORE_RISK`, which is what the screens actually show.

### 4.10 Citation preference

When a workflow row is newer than the screenshot or snapshot that establishes the same state, the
workflow row was winning the citation. The artifact an auditor would open is the file, so the file
is now cited whenever it agrees with the settled state, and the workflow id is only used when no
file names the record at all. The submission now cites files for 10 of the 11 records that
previously had only activity ids; the eleventh (`export_1842`) has no file anywhere in the dataset.

---

## 5. Remaining known gaps

These are the twelve step differences on the sample set: eleven missing expected steps and one extra
produced step.

| Case | Difference | Why |
|---|---|---|
| case_03 | missing `analytics_9406` VERIFY_RECORD_ANONYMIZED | analytics record with no identifier of any kind; nothing ties it to the subject |
| case_04 | missing `account_004` VERIFY_RECORD_ABSENT | `account_004` appears in no evidence file, activity row or audit row in the dataset |
| case_04 | missing `analytics_901` VERIFY_RECORD_ANONYMIZED | same null identifier problem as case_03 |
| case_18 | missing `audit_record_6645` VERIFY_RECORD_PRESENT | id appears nowhere in the dataset |
| case_20 | missing `audit_record_5569` VERIFY_RECORD_PRESENT | id appears nowhere in the dataset |
| case_21 | missing `analytics_5335` VERIFY_RECORD_ANONYMIZED | null identifier analytics record |
| case_23 | extra `account_9155`, missing `account_410` | two candidate accounts agree with the workflow status; the wrong one was chosen |
| case_25 | missing `analytics_1895` VERIFY_RECORD_ANONYMIZED | null identifier analytics record |
| case_26 | missing `analytics_4566` VERIFY_RECORD_ANONYMIZED | null identifier analytics record |
| case_27 | missing `analytics_4574` VERIFY_RECORD_ANONYMIZED | null identifier analytics record |
| case_28 | missing `analytics_6077` VERIFY_RECORD_ANONYMIZED | null identifier analytics record |

The seven null identifier analytics rows (`analytics_1895`, `4566`, `4574`, `5335`, `6077`, `901`,
`9406`) were examined as a group. They carry no email, phone, hash, name, user reference or
correlation key, and no ordering or ownership signal separates them. Attributing them to the subject
of the case would be a coin flip that is worth nothing: a wrong attribution adds a step that does
not exist and takes nothing away. They are deliberately not reported. The same reasoning applies to
`account_004`, `audit_record_5569` and `audit_record_6645`, which are not present anywhere in the
dataset.

`case_23` is the one genuine model error: two account records are compatible with the subject and
the workflow status, and the tie break chose the wrong one. The scoring function uses time proximity
to the reported deletion run plus status agreement; on that case both candidates score identically.
Resolving it would need a signal that does not exist in the data.
